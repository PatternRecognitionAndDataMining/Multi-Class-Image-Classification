pip3 install tensorflow
pip3 install opencv-python==3.4.0.12
pip3 install tqdm==4.19.6
pip3 install sklearn
pip3 install matplotlib
pip3 install pandas
